package it.eforhum.corsojava.documents;

import java.util.List;

public class DocumentPage {
	private List<Document> documents;
	private int totalResults;
	private int totalPages;
	
	private DocumentPage(Builder build){
		this.documents = build.documents;
		this.totalPages = build.totalPages;
		this.totalResults = build.totalResults;
	}
	
	public List<Document> getDocuments() {
		return documents;
	}
	public int getTotalResults() {
		return totalResults;
	}
	public int getTotalPages() {
		return totalPages;
	}


	
	public static class Builder{
		private List<Document> documents;
		private int totalResults;
		private int totalPages;
		
		
		public Builder() {			
			this.totalResults = 0;
			this.totalPages = 0;
		}
		
		public DocumentPage buildDocPage() {
			return new DocumentPage(this);
		}
		
		
		public Builder setDocuments(List<Document> documents) {
			this.documents = documents;
			return this;
		}
		public Builder setTotalResults(int totalResults) {
			this.totalResults = totalResults;
			return this;
		}
		public Builder setTotalPages(int totalPages) {
			this.totalPages = totalPages;
			return this;
		}
		
	}
}
